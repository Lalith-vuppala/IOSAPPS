//
//  Student Info ViewController.swift
//  StudentAPP
//
//  Created by Vuppala,Lalith on 11/7/23.
//

import UIKit

class StudentInfoViewController: UIViewController {
    
    
    @IBOutlet weak var SIDOL: UILabel!
    
    
    @IBOutlet weak var nameOL: UILabel!
    
    
    @IBOutlet weak var mailOL: UILabel!
    
    @IBOutlet weak var coursesBTN: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "Coursessegue"{
            let destination = segue.destination as! CoursesViewController
            
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
