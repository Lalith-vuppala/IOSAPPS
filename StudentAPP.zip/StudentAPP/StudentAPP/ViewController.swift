//
//  ViewController.swift
//  StudentAPP
//
//  Created by Vuppala,Lalith on 11/7/23.
//

import UIKit

class LoginViewController: UIViewController {
    

    @IBOutlet weak var sidOL: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }


    @IBAction func studetailsBTN(_ sender: UIButton) {
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "StudentSegue"
        {
                let destination = segue.destination as! StudentInfoViewController}
    }
}

