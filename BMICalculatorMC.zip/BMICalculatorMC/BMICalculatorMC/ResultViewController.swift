//
//  ResultViewController.swift
//  BMICalculatorMC
//
//  Created by Lalith Vuppala on 11/13/23.
//

import UIKit

class ResultViewController: UIViewController {

    
    @IBOutlet weak var Weight: UILabel!
    
    
    @IBOutlet weak var Height: UILabel!
    

    @IBOutlet weak var BMI: UILabel!
    
    
    @IBOutlet weak var ImageOL: UIImageView!
    var weight = ""
    var height = ""
    var BMICal = 0.0
    var imageName = " "
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        Weight.text! += weight
        Height.text! += height
        BMI.text! += String(BMICal)
        
        ImageOL.image = UIImage(named: imageName)
        var width = ImageOL.frame.width
        width += 100
        
        var height = ImageOL.frame.height
        height += 100
        ImageOL.frame.origin.x = 96.5
        var x = ImageOL.frame.origin.x
        ImageOL.frame.origin.y = 326
        var y = ImageOL.frame.origin.y
        print(x)
        print(y)
        
        //create a rectangle oject
        var largeFrame = CGRect(x: x, y: y, width: width, height: height)
        UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.5, initialSpringVelocity: 50,  animations: {
            self.ImageOL.frame = largeFrame
           
        })
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
