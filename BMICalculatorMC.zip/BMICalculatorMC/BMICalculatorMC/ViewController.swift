//
//  ViewController.swift
//  BMICalculatorMC
//
//  Created by Lalith Vuppala on 11/13/23.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var WeightOL: UITextField!
    
    
    @IBOutlet weak var HeightOL: UITextField!
    
    var imageName = ""
    var weight = 0.0
    var height = 0.0
    var BMI = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func CalBMIBtn(_ sender: Any) {
        
         weight = Double(WeightOL.text!)!
        height = Double(HeightOL.text!)!
                        
         
        
        
            BMI = (weight / (height * height)) * 703
        if(BMI <= 18.4 ){
            imageName = "underweight"
            
        }else if (BMI >= 18.5 && BMI <= 24.9){
            imageName = "healthy"
        }
        else if(BMI >= 24.9 && BMI <= 39.9){
            imageName = "overweight"
        }
        else{
            imageName = "OBESITY"
        }
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        
        if transition == "resultSegue"{
            let destinaiton = segue.destination as!
            ResultViewController
            destinaiton.weight = WeightOL.text!
            destinaiton.height = HeightOL.text!
            destinaiton.BMICal = BMI
            destinaiton.imageName = imageName
        }
    }
}

