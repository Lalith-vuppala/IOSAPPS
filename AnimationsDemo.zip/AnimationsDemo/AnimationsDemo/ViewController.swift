//
//  ViewController.swift
//  AnimationsDemo
//
//  Created by Lalith Vuppala on 10/24/23.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var HelloImageOL: UIImageView!
    
    
    @IBOutlet weak var HappyOL: UIButton!
    
    
    @IBOutlet weak var SadOL: UIButton!
    
    
    @IBOutlet weak var AngryOL: UIButton!
    
    
    @IBOutlet weak var ShakeMeOL: UIButton!
    
    @IBOutlet weak var ShowMeOL: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        // move the image view outsied of the screenview.
        HelloImageOL.frame.origin.x = view .frame.maxX;
        
        //similarly move other components outside of the screen.
        HappyOL.frame.origin.x = view.frame.width

        SadOL.frame.origin.x = view.frame.width
        AngryOL.frame.origin.x = view.frame.width
        ShakeMeOL.frame.origin.x = view.frame.width
        

    }

    @IBAction func HappyBtnClicked(_ sender: UIButton) {
        UpdateandAnimate("happy")
    }
    
    @IBAction func SadBtnClicked(_ sender: UIButton) {
        UpdateandAnimate("sad")
    }
    
    
    @IBAction func AngryBtnClicked(_ sender: UIButton) {
        UpdateandAnimate("angry")
    }
    
    
    @IBAction func ShakeMeBtnClicked(_ sender: UIButton) {
        
        //increase the image width and height for the component.
        
        
        var width = HelloImageOL.frame.width
        width += 40
        
        var height = HelloImageOL.frame.height
        height += 40
        
        var x = HelloImageOL.frame.origin.x - 20
        var y = HelloImageOL.frame.origin.x - 20
        
        //create a rectangle oject
        var largeFrame = CGRect(x: x, y: y, width: width, height: height)
     
        UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.5, initialSpringVelocity: 50,  animations: {
            self.HelloImageOL.frame = largeFrame
        })
        
    }
    
    
    @IBAction func ShowMeBtnClicked(_ sender: UIButton) {
        //Moving all the components to the center.
        UIView.animate(withDuration: 1, animations: {self.HelloImageOL.center.x = self.view.center.x
            self.HappyOL.center.x = self.view.center.x
            self.SadOL.center.x = self.view.center.x
            self.AngryOL.center.x = self.view.center.x
            self.ShakeMeOL.center.x = self.view.center.x
        })
        //disable the shoe me btn
        ShowMeOL.isEnabled = false
    }
    
    func UpdateandAnimate(_ imageName: String){
        
        //Make the curretn image as opaque.(aplha should be 0 )
        UIView.animate(withDuration: 1, animations: { self.HelloImageOL.alpha = 0})
        
        
        //Assign a new image and make it transparent(alpha should be 1.)
        UIView.animate(withDuration: 1, delay : 0.5, animations: 
                        {self.HelloImageOL.alpha = 1
            self.HelloImageOL.image = UIImage(named: imageName)
            
        }
        )
    }
}

