//
//  ViewController.swift
//  DiscountAppVC
//
//  Created by Vuppala,Lalith on 10/31/23.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var enterAmountOL: UITextField!
    
    
    @IBOutlet weak var enterDIscRateOL: UITextField!
    var priceAfterDiscount = 0.0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    @IBAction func CalculateBTN(_ sender: UIButton) {
        //read the data from enteredAmount
        
        var amount = Double(enterAmountOL.text!)
        //read the discRate from enterdiscrate

        var disc = Double(enterDIscRateOL.text!)
        
        
        priceAfterDiscount = amount! - (amount!*disc!/100)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        var transition = segue.identifier
    
        if transition == "resultSegue"{
    
            var destination = segue.destination as!
                ResultViewController
            destination.amount = enterAmountOL.text!
            destination.discRate = enterDIscRateOL.text!
            destination.priceAfterDiscount = priceAfterDiscount
        }
    }
}

