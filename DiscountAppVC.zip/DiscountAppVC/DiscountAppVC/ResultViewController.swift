//
//  ResultViewController.swift
//  DiscountAppVC
//
//  Created by Vuppala,Lalith on 10/31/23.
//

import UIKit

class ResultViewController: UIViewController {

    
    @IBOutlet weak var displayAmountOL: UILabel!
    
    
    @IBOutlet weak var displayDiscRateOL: UILabel!
    
    
    @IBOutlet weak var displayPriceAfterDiscOL: UILabel!
    
    
    var amount = ""
    var discRate = ""
    var priceAfterDiscount = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()

       
        
        displayAmountOL.text! += amount
        displayDiscRateOL.text! += discRate
        displayPriceAfterDiscOL.text! += String(priceAfterDiscount)
        

    }
    


}
