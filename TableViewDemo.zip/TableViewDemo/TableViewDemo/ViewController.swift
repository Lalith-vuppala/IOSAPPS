//
//  ViewController.swift
//  TableViewDemo
//
//  Created by Vuppala,Lalith on 11/9/23.
//

import UIKit
class product{
    var name: String?
    var category: String?
    
    init(name: String,category:String){
        self.name = name
        self.category = category
    }

}

class ViewController: UIViewController,  UITableViewDelegate, UITableViewDataSource {
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //returns the number of products.
        return productsArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //create the cell
        
        var cell = tableViewOL.dequeueReusableCell(withIdentifier: "resuableCell",for: indexPath)
        //populate the cell
        cell.textLabel?.text = productsArray[indexPath.row].name
        
        //return the cell
        return cell
        
        
    }
    

    
    
    @IBOutlet weak var tableViewOL: UITableView!
    
    var productsArray = [product]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let product1 = product(name: "MacBookAir", category: "laptop")
        let product2 = product(name: "iphone", category: "cellphone")
        let product3 = product(name: "iwatch", category: "Accesseories")
        let product4 = product(name: "Airpods", category: "Accessories")
        let product5 = product(name: "ipad", category: "Accesseories")
        
        productsArray.append(product1)
        productsArray.append(product2)
        productsArray.append(product3)
        productsArray.append(product4)
        productsArray.append(product5)
        
        
        tableViewOL.delegate = self
        tableViewOL.dataSource = self
        
        
        
        
    }


    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        
        if(transition == "productDetails"){
            let destination = segue.destination as!
            ProductDescriptionViewController
            
            destination.product = productsArray[(tableViewOL.indexPathForSelectedRow?.row)!]
        }
    }
}

