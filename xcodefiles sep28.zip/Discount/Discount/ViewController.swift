//
//  ViewController.swift
//  Discount
//
//  Created by Vuppala,Lalith on 9/21/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var inputOL: UITextField!
    
    
    @IBOutlet weak var inputOL1: UITextField!
    
    
    @IBOutlet weak var outputOL: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func CalculateBTN(_ sender: Any) {
        outputOL.text! = " \(calcDiscount(Amount: Double(inputOL.text!)!,DiscountPercentage:Double(inputOL1.text!)!))"
        
        func calcDiscount(Amount:Double,DiscountPercentage:Double)->Double{
            var DiscountAmount:Double = 0.0
            var AMountafterDiscount:Double = 0
            if(DiscountPercentage>0){
                DiscountAmount = (Amount/100) * DiscountPercentage
                AMountafterDiscount=Double(Amount - DiscountAmount)
            }
            return Double(AMountafterDiscount)
        }
        
        
    }
}
