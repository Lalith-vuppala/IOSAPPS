//
//  ViewController.swift
//  greaterNumber
//
//  Created by Vuppala,Lalith on 8/31/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var inputOL: UITextField!
    
    
    @IBOutlet weak var inputOL1: UITextField!
    
    
    @IBOutlet weak var outpulOL: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }

    @IBAction func Btnclicked(_ sender: UIButton) {
        
        // read the input text and assign the variables.
        var input = inputOL.text!
        
        // read the input text1 and assign the variables.
        var input1 = inputOL1.text!
        
        // check if the input is greather than input1
        let myStringvaribale = "10"
        let myStringvarible1 = "29"
        if(input1 > input){
            outputOL.text = "the \(input1) is greather than  input"
        }
        else(input > input1){
            outputlOL.text = "the \(input)is greather than input1"
            
        }
        //if the inpput1 is greater than input2 print "input1 is> input2".
        //else the input2 is greater than input1 print "input2 is> input1".
        
    }
    
}

