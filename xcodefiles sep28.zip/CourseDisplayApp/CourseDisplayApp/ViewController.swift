//
//  ViewController.swift
//  CourseDisplayApp
//
//  Created by Vuppala,Lalith on 9/28/23.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var imgDisplay: UIImageView!
    
    
    @IBOutlet weak var crsNumber: UILabel!
    
    
    @IBOutlet weak var crsName: UILabel!
    
    
    @IBOutlet weak var semOffered: UILabel!
    
    
    @IBOutlet weak var PreviousBtnOL: UIButton!
    
    
    @IBOutlet weak var NextBtnOL: UIButton!
    
    //create an array of courses
    
    var courses = [["img01","44542","Network Security", "Fall 2023"],
        ["img02","44786","IOS","Spring 2023"],
        ["img03","44476","Big Data","Spring2024"]]
    
    var imgNumber = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //previousBTN is disabled.
        PreviousBtnOL.isEnabled = false
        
        //Display the first course details
        crsNumber.text = courses[0][1]
        crsName.text = courses[0][2]
        semOffered.text = courses[0][3]
        
        imgDisplay.image = UIImage(named: courses[0][0])
        
    }

    
    
    
    @IBAction func PrevBTNClicked(_ sender: UIButton) {
        
        
        //Enable the next button.
        NextBtnOL.isEnabled = true
        
        //decrement the image number
        imgNumber -= 1
        
        
        //update the image using updateDisplay function.
        updateDisplay(imgNumber)
        
        
        //if we reach the begining of the array previous BTN should be disabled.
        if(imgNumber == 0){
            PreviousBtnOL.isEnabled = false
        }
        
    }
    
    
    
    @IBAction func NextBtnClicked(_ sender: UIButton) {
         //previous BTN should be enabled
        PreviousBtnOL.isEnabled = true
        
        //Next element in the course array must be displayed.
        imgNumber += 1
        
        crsNumber.text = courses[imgNumber][1]
        
        crsName.text = courses[imgNumber][2]
        
        semOffered.text = courses[imgNumber][3]
        
        imgDisplay.image = UIImage(named: courses[imgNumber][0])
        
    //When you reach the end of the array,Next BTN should be disabled.
        if(imgNumber == courses.count-1){
            NextBtnOL.isEnabled = false
            
        }
        
        
    }
    func updateDisplay(_ imageNumber:Int){
        crsNumber.text = courses[imgNumber][1]
        crsName.text = courses[imgNumber][2]
        semOffered.text = courses[imgNumber][3]
        imgDisplay.image = UIImage(named: courses[imageNumber][0])
    }
    
    
    

    
    
    
}

