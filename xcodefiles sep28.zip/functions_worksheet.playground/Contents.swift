import UIKit

var greeting = "Hello, playground"


func greetUser(){
    print("Welcome User")
}
greetUser()
func sayHello()->String{
    var name="Swift"
    return "Hello "+name+"!"
}
print(sayHello())


func favoriteProgram(name:String)->String{
    var name="My favorite programming language is \(name)"
    return name
}
print(favoriteProgram(name: "java"))

func addNumbers(number1:Int,number2:Int)->Int{
    return number1+number2
    
}
print("The sum of given number is \(addNumbers(number1: 10, number2: 20))")


func manipulateNumber(input: Int,mode:Bool)->String{
    var counter=input
    if(mode){
        counter+=2
    }
    else{
        counter-=1
    }
    return "The \(mode ? "incremented" : "decremented") vslue is \(counter)"
}
var val=19
print(manipulateNumber(input: val, mode: false))


func login(sid username:String, password:String)->Bool{
    if(username=="swift5.5" && password=="uikit"){
        return true
    }
    return false;
}
var loggedIn:Bool = login(sid: "swift5.5", password: "uikit")

if loggedIn{
    print("user login success")
    
}
else{
    print("Username or Passweord is incorrect")
}

func fullName(_ firstName:String,_ lastName:String)->String{
    return lastName+","+firstName
}
print(fullName("Susan","Connar"))


func sumAndAvg(_ numbers:Double...)->(sum:Double,avg:Double){
    var total:Double=0
    var avg:Double
    for number in numbers{
        total+number
    }
    avg=total/Double(numbers.count)
    return (total,avg)
}
let result=sumAndAvg(1,22.3,4,54.5,30,44,67)
print("Sum = \(result.sum)")
print("Average = \(result.avg)")



