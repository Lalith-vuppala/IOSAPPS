import UIKit

var capitals = ["Arkansas":"LittleRock","Georgia":"Atlanta"]
print(capitals)
print(capitals.count)

var numbers = [1:"one",2:"Two",3:"Three"]
print(numbers)

var course = [44542:"Java", 44768:"Mobile computing", 44465:"Database",44475:"Webapps"]

print("Before changing \(course)")
course[44542] = "java script"
print("After changing \(course)")

print(course[44542])


course.removeValue(forKey: 44475)
print(course)


for(key,value) in course{
    print(key)
}


for(key,value) in course{
    print(value)
}
for (key,value) in course{
    print("\(key) : \(value)")
}

course[44476] = "Webapps"
print(course)

var players : Set<String> = ["David Warner","Virat kohli", "M.s.Dhoni","Sachin Tendulkar"]

print(players.count)
print(players)
players.insert("Maxwell")
print(players)
players.remove("David Warner")
print(players)

var primeNumbers : Set<Int> = [2,3,5,7,11]
var numbersList : Set<Int> = [1,2,5,9]

var unionSet : Set<Int> = primeNumbers.union(numbersList)
print(unionSet)


var intersectionSet : Set<Int> =
primeNumbers.intersection(numbersList)
print(intersectionSet)


var subtractionSet : Set<Int> =
primeNumbers.subtracting(numbersList)
print(subtractionSet)


var shoppingList = ["Eggs", "Milk","Cake"]
print("The shoppingLIst contains \(shoppingList)")


