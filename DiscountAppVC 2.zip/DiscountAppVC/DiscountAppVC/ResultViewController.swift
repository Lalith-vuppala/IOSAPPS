//
//  ResultViewController.swift
//  DiscountAppVC
//
//  Created by Vuppala,Lalith on 10/31/23.
//

import UIKit

class ResultViewController: UIViewController {

    
    @IBOutlet weak var displayAmountOL: UILabel!
    
    
    @IBOutlet weak var displayDiscRateOL: UILabel!
    
    
    @IBOutlet weak var displayPriceAfterDiscOL: UILabel!
    
    @IBOutlet weak var imageOL: UIImageView!
    
    var amount = ""
    var discRate = ""
    var priceAfterDiscount = 0.0
    var imageName = ""
    override func viewDidLoad() {
        super.viewDidLoad()

       
        
        displayAmountOL.text! += amount
        displayDiscRateOL.text! += discRate
        displayPriceAfterDiscOL.text! += String(priceAfterDiscount)
        
        imageOL.image = UIImage(named: imageName)
        
        

    }
    


}
