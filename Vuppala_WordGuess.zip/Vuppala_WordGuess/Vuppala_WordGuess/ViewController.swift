//
//  ViewController.swift
//  Vuppala_WordGuess
//
//  Created by Vuppala,Lalith on 10/17/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var wordsGuessedLabel: UILabel!
    
    @IBOutlet weak var wordsRemaningLabel: UILabel!
    
    @IBOutlet weak var totalWordsLabel: UILabel!
    
    @IBOutlet weak var userGuessLabel: UILabel!
    
    @IBOutlet weak var guessLetterField: UITextField!
    
    @IBOutlet weak var hintLabel: UILabel!
    
    @IBOutlet weak var guessCountLabel: UILabel!
    
    @IBOutlet weak var statusLabel: UILabel!
    
    
    @IBOutlet weak var displayImage: UIImageView!
    
    
    //declear an array with 5 words and related hits.
    
    var words = [["QDOBA", "Mexican food Stall","Qdoba"],
    ["PYTHON", "programming language","Python"],
                 ["DELL","A laptop","dell"],
                 ["THE VAMPIR DAIRIES","A famous supernatural series","TVD"],
                 ["HARRYPOTTER","The famous fictional movie","Harry Potter"]]
    
    
    var count = 0;
    var word = ""
    var lettersGuessed = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        word = words[0][1];
        
        
        userGuessLabel.text! = ""
        
       updateU
        
        
    }

    @IBAction func guessLetterButtonPressed(_ sender: UIButton) {
    }
    
    
    
    @IBAction func playAgainButtonPressed(_ sender: UIButton) {
    }
    
    
}

